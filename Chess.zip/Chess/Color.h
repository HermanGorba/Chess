#pragma once
enum class Color
{
	White, Black
};

Color getOposite(const Color& color);

