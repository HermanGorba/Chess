#pragma once
enum class Status
{
	GameOn, Stalemate, CheckmateToWhite, CheckMateToBlack
};